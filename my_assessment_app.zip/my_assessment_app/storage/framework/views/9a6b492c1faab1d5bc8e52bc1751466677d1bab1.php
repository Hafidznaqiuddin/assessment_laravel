<?php echo e($slot); ?>

<?php /**PATH C:\Users\ASUS\Downloads\assessment-app\my_assessment_app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>